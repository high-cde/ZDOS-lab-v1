# ZLANG portable bundle

This developer bundle intentionally excludes the bootable ISO.
Use the included manifest and SHA-256 file before extracting or running code.

Windows 7 is supported as a preparation target only: native `.exe` output requires a Windows-compatible cross-build and a real Windows 7 test.
