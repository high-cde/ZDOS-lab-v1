const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const DB_DIR = process.env.ZDOS_SEC_DATA_DIR || path.join(__dirname, 'data');
const FEED_FILE = `${DB_DIR}/social_feed.json`;
const CHAIN_FILE = `${DB_DIR}/zchain_ledger.json`;
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });

let socialFeed = []; let zChainLedger = [];
if (fs.existsSync(FEED_FILE)) socialFeed = JSON.parse(fs.readFileSync(FEED_FILE));
if (fs.existsSync(CHAIN_FILE)) zChainLedger = JSON.parse(fs.readFileSync(CHAIN_FILE));

const saveData = () => {
    fs.writeFileSync(FEED_FILE, JSON.stringify(socialFeed, null, 2));
    fs.writeFileSync(CHAIN_FILE, JSON.stringify(zChainLedger, null, 2));
};

app.post('/api/sync/submit', (req, res) => {
    const { title, url, author } = req.body;
    if (!title || !url) return res.status(400).json({ error: "Dati corrotti." });
    
    const newPost = { id: socialFeed.length + 1, title, author: author || "Ghost_Agent", url };
    socialFeed.unshift(newPost);
    
    const newHash = "0xZD" + Math.random().toString(16).slice(2) + Date.now().toString(16);
    const newBlock = { block: zChainLedger.length, hash: newHash, data: `TX_SOCIAL: [${author || "Ghost_Agent"}] -> ${title}`, status: "MINED_SUCCESS" };
    zChainLedger.unshift(newBlock);
    
    saveData();
    io.emit('update_social', newPost);
    io.emit('update_chain', newBlock);
    res.json({ success: true });
});

app.post('/api/core/compile', (req, res) => {
    let { zcode, pass } = req.body;
    
    // 🛑 CONTROLLO ACCESSO: IL LUCCHETTO
    if (pass !== "Z-CYBERCORE-2026") {
        return res.json({ success: false, output: "ACCESSO NEGATO: Password Comandante Errata.\n" });
    }

    if (!zcode) return res.status(400).json({ error: "Nessun payload." });

    // HACK: Pre-processore Z-Lang v1.2 (Matematica + Variabili di Memoria)
    zcode = zcode.replace(/calc\s+(\d+)\s*([\+\-\*\/])\s*(\d+)/g, (match, p1, op, p2) => {
        let result = 0;
        if (op === '+') result = parseInt(p1) + parseInt(p2);
        if (op === '-') result = parseInt(p1) - parseInt(p2);
        if (op === '*') result = parseInt(p1) * parseInt(p2);
        if (op === '/') result = parseInt(p1) / parseInt(p2);
        return `emit [MATH] Risultato di ${p1} ${op} ${p2} = ${result}`;
    });

    zcode = zcode.replace(/let\s+([a-zA-Z0-9_]+)\s*=\s*(\d+)/g, (match, varName, value) => {
        return `emit [MEMORY] Variabile '${varName}' allocata nell'heap virtuale con valore ${value}.`;
    });

    const zdosRoot = process.env.ZDOS_ROOT || path.resolve(__dirname, '..', 'ZDOS');
    const filepath = path.join(zdosRoot, 'os/x86_64/programs/boot.zlang');
    if (!fs.existsSync(path.dirname(filepath))) {
        return res.status(503).json({ success: false, output: 'ZDOS checkout non disponibile: impostare ZDOS_ROOT.\\n' });
    }
    fs.writeFileSync(filepath, zcode);

    const buildDir = path.join(zdosRoot, 'os/x86_64');
    const cmd = `cd "${buildDir}" && make clean && make verify && sh tools/verify_qemu.sh`;
    const child = spawn('sh', ['-c', cmd]);

    child.stdout.on('data', (data) => io.emit('terminal_stream', data.toString()));
    child.stderr.on('data', (data) => io.emit('terminal_stream', data.toString()));
    child.on('close', (code) => io.emit('terminal_stream', `\n[SISTEMA] Processo terminato con codice ${code}\n`));

    res.json({ success: true, message: "Forgiatura autorizzata." });
});

app.get('/api/social/feed', (req, res) => res.json(socialFeed));
app.get('/api/chain/ledger', (req, res) => res.json(zChainLedger));

const PORT = 3010;
server.listen(PORT, "0.0.0.0", () => console.log(`[ZDOS-SEC] Core Blindato su ${PORT}`));
