import { readFileSync } from 'node:fs';

const index = readFileSync(new URL('../public/index.html', import.meta.url), 'utf8');
const telemetry = readFileSync(new URL('../public/telemetry.html', import.meta.url), 'utf8');
const checks = [
  ['index theme link', index.includes('/zdos-theme.css')],
  ['index control center', index.includes('ZDOS CONTROL CENTER')],
  ['index compile panel', index.includes('ZLB2 COMPILE & QEMU EXECUTION')],
  ['telemetry theme link', telemetry.includes('/zdos-theme.css')],
  ['telemetry ledger', telemetry.includes('EVIDENCE CHAIN LEDGER')],
];
for (const [name, ok] of checks) {
  console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`);
  if (!ok) process.exitCode = 1;
}
