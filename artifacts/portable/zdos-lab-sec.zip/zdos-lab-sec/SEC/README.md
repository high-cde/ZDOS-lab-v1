![ZDOS-SEC Portal](https://capsule-render.vercel.app/api?type=waving&color=0:09090b,35:172554,68:0e7490,100:ef4444&height=230&section=header&text=ZDOS-SEC&fontSize=68&fontColor=ffffff&animation=fadeIn&fontAlignY=38&desc=Operational%20HUD%20%2B%20Z-Chain%20Telemetry%20Portal&descAlignY=61&descSize=18)

# 🛰️ ZDOS-SEC-PORTAL · Plancia HUD v3.0

[![Node](https://img.shields.io/badge/runtime-Node.js-16a34a?style=for-the-badge&logo=node.js&logoColor=white)](https://nodejs.org/)
[![Express](https://img.shields.io/badge/server-Express-111827?style=for-the-badge&logo=express&logoColor=white)](https://expressjs.com/)
[![Socket.IO](https://img.shields.io/badge/realtime-Socket.IO-010101?style=for-the-badge&logo=socketdotio&logoColor=white)](https://socket.io/)
[![Status](https://img.shields.io/badge/status-prototipo%20operativo-f59e0b?style=for-the-badge&logo=github&logoColor=white)](https://github.com/high-cde/ZDOS-SEC-PORTAL/actions)
[![Ecosystem](https://img.shields.io/badge/ecosystem-ZDOS-2563eb?style=for-the-badge)](https://github.com/high-cde/ZDOS)
[![ZLB2](https://img.shields.io/badge/contract-ZLB2%20v2.5-7c3aed?style=for-the-badge)](https://github.com/high-cde/Zlang)
[![Security boundary](https://img.shields.io/badge/security-boundary%20required-ef4444?style=for-the-badge&logo=shield&logoColor=white)](#-sicurezza-prima-del-deployment)

> **ZDOS-SEC-PORTAL è una plancia web operativa per l’ecosistema ZDOS:** visualizza feed social, ledger locale e stream di compilazione tramite una HUD neon in tempo reale.

## ⚡ Funzionalità

| Modulo | Funzione | Stato |
|---|---|---|
| 🛰️ **Command HUD** | Dashboard a due colonne con stato operativo e collegamento al comando esterno | Disponibile |
| ✍️ **Social injection** | Inserisce titolo, URL e alias nel feed locale | Disponibile |
| ⛓️ **Z-Chain ledger** | Crea una voce ledger locale associata a ogni invio | Prototipo locale |
| 🔌 **Realtime stream** | Aggiorna feed, ledger e terminale tramite Socket.IO | Disponibile |
| ⚙️ **Z-Lang forge** | Avvia il percorso di compilazione ZDOS x86_64 da un payload | Laboratorio protetto da autenticazione |
| 📡 **Telemetry** | Pagina dedicata alla telemetria del ledger | Disponibile |

## 🧬 Architettura

```mermaid
flowchart LR
    U[👩‍💻 Operator] --> H[🛰️ HUD public/index.html]
    H <--> S[🔌 Socket.IO]
    H --> A[🌐 Express API]
    A --> F[(📄 social_feed.json)]
    A --> L[(⛓️ zchain_ledger.json)]
    A --> C[⚙️ ZDOS x86_64 build]
    C --> Q[🖥️ QEMU + serial stream]
    S --> H
```

Il server Express serve `public/`, espone le API JSON e mantiene gli aggiornamenti live con Socket.IO. I dati locali sono salvati nella directory configurata dal server. La forgiatura Z-Lang avvia un processo esterno e inoltra stdout/stderr agli operatori collegati.

## 🧰 Prerequisiti e configurazione

Il portale richiede Node.js, npm e i repository ZDOS/Zlang soltanto quando viene utilizzata la pipeline di compilazione. I percorsi, le porte e i secret devono essere configurati tramite environment o file locale non tracciato; non inserire credenziali nel repository.

| Variabile/risorsa | Uso | Default/documentazione |
|---|---|---|
| `PORT` | Porta HTTP del portale | `3010` |
| Repository ZDOS | Build e test della distro | Checkout locale autorizzato |
| Zlang | Contratto e compilatore ZLB2 | Checkout locale autorizzato |
| Evidence Chain | Attestazioni di build/boot | Repository ZDOS `evidence/` |

## 🚀 Avvio locale

```sh
git clone https://github.com/high-cde/ZDOS-SEC-PORTAL.git
cd ZDOS-SEC-PORTAL
npm ci
node server.js
```

Il portale ascolta su `http://localhost:3010`. Per usare la funzione di compilazione è necessario disporre del repository ZDOS nel percorso previsto dal server e del compilatore Zlang configurato nel workflow ZDOS.

## 🔌 API HTTP

| Metodo | Endpoint | Scopo |
|---|---|---|
| `GET` | `/api/social/feed` | Restituisce il feed sociale locale |
| `GET` | `/api/chain/ledger` | Restituisce il ledger locale |
| `POST` | `/api/sync/submit` | Inserisce un post e crea un record ledger |
| `POST` | `/api/core/compile` | Avvia la pipeline ZDOS x86_64 e streamma il risultato |

Esempio di invio al feed:

```sh
curl -X POST http://localhost:3010/api/sync/submit \
  -H 'content-type: application/json' \
  -d '{"title":"ZDOS boot verified","url":"https://github.com/high-cde/ZDOS","author":"operator"}'
```

## 🔔 Eventi Socket.IO

| Evento | Direzione | Contenuto |
|---|---|---|
| `terminal_stream` | server → client | Output della build e del test QEMU |
| `update_social` | server → client | Nuovo elemento del feed |
| `update_chain` | server → client | Nuovo blocco ledger |

## 🧪 Quick check

Dopo l'avvio, verificare prima gli endpoint di sola lettura:

```sh
curl -fsS http://localhost:3010/api/social/feed
curl -fsS http://localhost:3010/api/chain/ledger
```

Le chiamate `POST` e la compilazione devono essere eseguite soltanto in ambiente di laboratorio autorizzato.

## 🔁 Gate di integrazione

Il portale deve essere trattato come livello Operations dell’ecosistema. Prima di pubblicare un evento di release, la pipeline deve verificare il compilatore Zlang, il contratto ZLB2, il build/boot ZDOS e l’attestazione Evidence Chain. Il portale può visualizzare questi risultati, ma non può sostituire i verificatori.

Sequenza minima:

```text
Zlang contract → ZDOS build → QEMU boot → Evidence Chain → SEC telemetry
```

Gli stati della HUD devono rappresentare eventi ricevuti e verificabili, non simulare un successo locale. Per la sincronizzazione completa dal checkout ZDOS è disponibile `./scripts/sync-ecosystem.sh`.

## 🛡️ Sicurezza prima del deployment

Questo portale è un **prototipo operativo**, non un servizio pronto per Internet. Prima di un deployment pubblico sono obbligatori autenticazione reale, password e secret esclusivamente tramite environment, rate limiting, CSRF protection, validazione e allowlist degli URL, logging strutturato, sandbox del processo di compilazione, timeout, isolamento filesystem e controllo degli eventi Socket.IO.

In particolare, la pipeline di compilazione esegue processi esterni e scrive un file Zlang nel repository ZDOS. Non esporre `/api/core/compile` senza isolare il worker e rimuovere qualsiasi credenziale hard-coded dal codice sorgente.

## 🧱 Modello degli stati

La HUD deve distinguere sempre tra stato configurato, raggiungibile e verificato. Un endpoint HTTP, un badge o una stringa ricevuta via Socket.IO non sono prove sufficienti.

| Stato | Significato operativo |
|---|---|
| `CONFIGURED` | Parametri presenti, nessuna prova di raggiungibilità |
| `REACHABLE` | Endpoint raggiungibile, nessuna attestazione di correttezza |
| `VERIFIED` | Gate e prova associata completati |
| `REVOKED` | Attestazione revocata o non più valida |
| `NOT_VERIFIED` | Mancano prove o un controllo è fallito |

## 🧪 Verifica operativa

Il repository non include ancora una suite automatica completa. La verifica minima manuale è:

```sh
npm ci
node server.js
curl -fsS http://localhost:3010/api/social/feed
curl -fsS http://localhost:3010/api/chain/ledger
```

La milestone successiva dovrebbe aggiungere test HTTP, test Socket.IO, test di persistenza, test di input non valido e un worker di compilazione isolato.

## 🗺️ Roadmap operativa

| Fase | Obiettivo | Gate di uscita |
|---|---|---|
| 1. 🧪 Laboratorio | Test HTTP/Socket.IO e dati locali | Suite automatica ripetibile |
| 2. 🔒 Isolamento | Worker separato per la compilazione | Timeout, filesystem e privilegi confinati |
| 3. 🪪 Identità | Autenticazione e autorizzazione reale | Ruoli, sessioni e audit |
| 4. ✅ Attestazione | Integrare Evidence Chain e release | Prove firmate e stati verificabili |
| 5. 🌐 Deployment | Esposizione pubblica controllata | Threat model, monitoraggio e rollback |

## ⛓️ Evidence Chain e stati verificabili

Il portale può visualizzare eventi del ledger locale e attestazioni provenienti dall’ecosistema ZDOS, ma non certifica automaticamente anonimato, cifratura, Tor o sicurezza del nodo. Gli eventi di build e boot devono essere verificabili e i dati sensibili devono restare fuori catena.

Gli stati dell’interfaccia devono distinguere tra `CONFIGURED`, `REACHABLE`, `VERIFIED`, `REVOKED` e `NOT_VERIFIED`. Una risposta HTTP statica, un badge verde o una stringa nella HUD non costituiscono da soli una prova di sicurezza.

Il contratto della Evidence Chain e il verificatore sono documentati nel [repository ZDOS](https://github.com/high-cde/ZDOS/tree/main/evidence). Il runtime Zlang collegato usa il profilo ZLB2 v2.5; il portale resta un’operational HUD di laboratorio e non un servizio C2 pronto per Internet.

## 📦 Comandi di manutenzione

```sh
npm ci
node server.js
# in un'altra shell:
curl -fsS http://localhost:3010/api/social/feed
curl -fsS http://localhost:3010/api/chain/ledger
```

Prima di un commit:

```sh
git diff --check
npm ci
```

## 🔗 Ecosistema

- [ZDOS](https://github.com/high-cde/ZDOS) · kernel, distro Linux e documentazione principale
- [Zlang](https://github.com/high-cde/Zlang) · compilatore e contratto ZLB2 v2.5
- [ZDOS x86_64](https://github.com/high-cde/ZDOS/tree/main/os/x86_64) · percorso bare-metal verificato

---

**ZDOS-SEC** · _Observe the system. Prove the path. Secure the boundary._ ✨

![Footer](https://capsule-render.vercel.app/api?type=waving&color=0:ef4444,42:0e7490,100:312e81&height=120&section=footer)
