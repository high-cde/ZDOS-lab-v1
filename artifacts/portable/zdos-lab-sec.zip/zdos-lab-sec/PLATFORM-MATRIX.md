# ZDOS portable package

This package is separate from the ZDOS ISO and contains development/runtime sources.

| Platform | Artifact | Status |
|---|---|---|
| Linux x86_64 | tar.gz / zip | VERIFIED in the build environment |
| Ubuntu, Kali, Parrot | source bundle + launcher | PREPARED; use the distro package manager for dependencies |
| Windows 7 | zip + `.cmd` launcher | PREPARED; requires a compatible Python/Node runtime |
| Native `.exe` | not emitted by this host | NOT_VERIFIED until cross-build and Windows 7 test |

Do not treat a Windows wrapper as a native executable. Checksums in `SHA256SUMS` identify the exact archive.
