#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

ROOT="${ZDOS_WORKSPACE:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
ZDOS="${ZDOS_ROOT:-$ROOT/ZDOS}"
ZLANG="${ZLANG_ROOT:-$ROOT/Zlang}"
SEC="${SEC_ROOT:-$ROOT/ZDOS-SEC-PORTAL}"
OUT="${ZDOS_OUTPUT:-$ROOT/out}"
PROFILE="${ZDOS_PROFILE:-live}"
TARGET="${ZDOS_TARGET:-x86_64}"
PERSIST_SIZE="${ZDOS_PERSIST_SIZE:-4096}"
DRY_RUN=0
SKIP_BUILD=0

usage() {
  cat <<'ZDOS_USAGE'
Uso:
  ./zdos-unified-build.sh [--live|--persistent|--dry-run] [--skip-build] [--target TARGET]

Output:
  out/zdos-linux-x86_64-base.iso
  out/zdos-unified-layer.tar.gz
  out/zdos-persistent.qcow2       se si usa --persistent
  out/system-manifest.txt
ZDOS_USAGE
}

log() { printf '\n[ZDOS] %s\n' "$*"; }
run() { if (( DRY_RUN )); then printf '[DRY-RUN]'; printf ' %q' "$@"; printf '\n'; else "$@"; fi; }
need_dir() { [[ -d "$1" ]] || { printf '[ERRORE] directory mancante: %s\n' "$1" >&2; exit 1; }; }

while (($#)); do
  case "$1" in
    --live) PROFILE=live ;;
    --persistent) PROFILE=persistent ;;
    --dry-run) DRY_RUN=1 ;;
    --skip-build) SKIP_BUILD=1 ;;
    --target) shift; TARGET="${1:?manca il valore di --target}" ;;
    --target=*) TARGET="${1#*=}" ;;
    -h|--help) usage; exit 0 ;;
    *) printf '[ERRORE] opzione sconosciuta: %s\n' "$1" >&2; usage; exit 2 ;;
  esac
  shift
done

case "$TARGET" in
  x86_64|aarch64|riscv64) ;;
  *) printf '[ERRORE] target non supportato: %s (scegli x86_64, aarch64 o riscv64)\n' "$TARGET" >&2; exit 2 ;;
esac
need_dir "$ZDOS"
need_dir "$ZLANG"
[[ -d "$SEC" ]] || printf '[AVVISO] portale SEC non trovato: %s\n' "$SEC" >&2
mkdir -p "$OUT"

log "Verifica prerequisiti"
for cmd in bash sha256sum find tar; do
  command -v "$cmd" >/dev/null || { printf '[ERRORE] manca il comando: %s\n' "$cmd" >&2; exit 1; }
done
if [[ -f "$ZDOS/tools/zdosctl.py" ]]; then
  command -v python3 >/dev/null || { printf '[ERRORE] manca il comando: python3 (richiesto da zdosctl)\n' >&2; exit 1; }
fi
if [[ $SKIP_BUILD -eq 0 && $DRY_RUN -eq 0 ]]; then
  for cmd in cpio gzip; do
    command -v "$cmd" >/dev/null || { printf '[ERRORE] manca il comando per la build distro: %s\n' "$cmd" >&2; exit 1; }
  done
fi

log "Verifica sorgenti"
if [[ -f "$ZLANG/tools/zlangc.py" ]]; then
  printf 'ZLANG_COMPILER=%s\n' "$ZLANG/tools/zlangc.py"
else
  printf '[AVVISO] compilatore Zlang Python non trovato.\n' >&2
fi

if [[ "$TARGET" != x86_64 ]]; then
  printf '[AVVISO] target %s: profilo dichiarativo preparato, build kernel/driver non ancora implementata.\n' "$TARGET" >&2
fi
if [[ "$TARGET" == x86_64 && -f "$ZDOS/distro/build.sh" && $SKIP_BUILD -eq 0 ]]; then
  log "Costruzione base Linux ZDOS x86_64"
  if (( DRY_RUN )); then
    printf '[DRY-RUN] (cd %q && ./distro/build.sh)\n' "$ZDOS"
  else
    (cd "$ZDOS" && ./distro/build.sh)
  fi
fi

log "Preparo layer unificato"
STAGE="$OUT/stage"
if (( ! DRY_RUN )); then
  rm -rf "$STAGE"
  mkdir -p "$STAGE/opt/zdos" "$STAGE/etc/profile.d"
fi

copy_if_exists() {
  local src="$1" dst="$2"
  if [[ -e "$src" ]]; then
    run cp -a "$src" "$dst"
  else
    printf '[AVVISO] assente: %s\n' "$src" >&2
  fi
}
copy_if_exists "$ZLANG" "$STAGE/opt/zdos/Zlang"
copy_if_exists "$SEC" "$STAGE/opt/zdos/ZDOS-SEC-PORTAL"
copy_if_exists "$ZDOS/core" "$STAGE/opt/zdos/core"
copy_if_exists "$ZDOS/os/ghostnet" "$STAGE/opt/zdos/ghostnet"
copy_if_exists "$ZDOS/tools/zdosctl.py" "$STAGE/opt/zdos/zdosctl.py"
copy_if_exists "$ZDOS/tools/zdosctl" "$STAGE/opt/zdos/zdosctl"
copy_if_exists "$ZDOS/policies" "$STAGE/opt/zdos/policies"

if (( ! DRY_RUN )); then
  cat > "$STAGE/etc/profile.d/zdos.sh" <<'ZDOS_PROFILE'
export ZDOS_HOME=/opt/zdos
export ZLANG_HOME=/opt/zdos/Zlang
export PATH="$ZDOS_HOME/bin:$PATH"
ZDOS_PROFILE
  cat > "$STAGE/opt/zdos/README-RUNBOOK.md" <<'ZDOS_RUNBOOK'
# ZDOS Unified Runtime

Questa immagine integra ZDOS Linux, Zlang e i componenti SEC come layer osservabili.
Il kernel attuale non è interamente scritto in Zlang: boot, assembly/C, Linux e BusyBox restano dipendenze del target x86_64.

## Evidence-first cockpit

`/opt/zdos/zdosctl inspect` mostra repository, commit, toolchain, profili hardware e policy.
`/opt/zdos/zdosctl manifest --output /opt/zdos/manifest.json` genera l’identità SHA-256 del layer e delle sorgenti.
`/opt/zdos/zdosctl policy check /opt/zdos/policies/diagnostic-readonly.json` valida una policy default-deny prima dell’esecuzione.

ARM64 e RISC-V restano PREPARED finché kernel, firmware, driver, test QEMU e artefatti riproducibili non saranno verificati.
ZDOS_RUNBOOK
fi

log "Raccolgo gli artefatti"
BASE_ISO="$ZDOS/distro/build/zdos-linux-${TARGET}.iso"
if [[ "$TARGET" == x86_64 ]]; then BASE_ISO="$ZDOS/distro/build/zdos-linux-x86_64.iso"; fi
if [[ -f "$BASE_ISO" && $DRY_RUN -eq 0 ]]; then
  cp "$BASE_ISO" "$OUT/zdos-linux-${TARGET}-base.iso"
  tar -C "$STAGE" -czf "$OUT/zdos-unified-layer.tar.gz" .
  if [[ -f "$ZDOS/tools/zdosctl.py" ]]; then
    log "Genero manifest canonico dell’ecosistema"
    ZDOS_ROOT="$ZDOS" ZLANG_ROOT="$ZLANG" SEC_ROOT="$SEC" ZDOS_WORKSPACE="$ROOT" \
      python3 "$ZDOS/tools/zdosctl.py" manifest --output "$OUT/zdos-artifact-manifest.json"
  fi
elif (( ! DRY_RUN )); then
  printf '[AVVISO] ISO base non disponibile; eseguire senza --skip-build.\n' >&2
fi

if [[ "$PROFILE" == persistent ]]; then
  log "Creo disco persistente"
  if command -v qemu-img >/dev/null 2>&1; then
    run qemu-img create -f qcow2 "$OUT/zdos-persistent.qcow2" "${PERSIST_SIZE}M"
  else
    printf '[AVVISO] qemu-img non installato: persistenza non generata.\n' >&2
  fi
fi

if (( ! DRY_RUN )); then
  {
    printf 'profile=%s\n' "$PROFILE"
    printf 'target=%s\n' "$TARGET"
    printf 'support_level=%s\n' "$([[ "$TARGET" == x86_64 ]] && echo verified || echo planned)"
    printf 'built_at_utc=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    printf 'zdos_commit=%s\n' "$(git -C "$ZDOS" rev-parse HEAD 2>/dev/null || echo unknown)"
    printf 'zlang_commit=%s\n' "$(git -C "$ZLANG" rev-parse HEAD 2>/dev/null || echo unknown)"
    printf 'sec_commit=%s\n' "$(git -C "$SEC" rev-parse HEAD 2>/dev/null || echo unknown)"
    find "$OUT" -maxdepth 1 -type f -print0 | sort -z | xargs -0 -r sha256sum
  } > "$OUT/system-manifest.txt"
fi

log "Build completata"
printf 'ISO base: %s\n' "$OUT/zdos-linux-${TARGET}-base.iso"
printf 'Layer:    %s\n' "$OUT/zdos-unified-layer.tar.gz"
[[ "$PROFILE" == persistent ]] && printf 'Persistenza: %s\n' "$OUT/zdos-persistent.qcow2"
printf 'Nota: x86_64 è il solo target buildato/verificato; aarch64 e riscv64 sono profili preparatori e richiedono kernel, driver, firmware e test dedicati.\n'
