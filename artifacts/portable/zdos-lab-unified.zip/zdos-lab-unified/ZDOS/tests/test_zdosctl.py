#!/usr/bin/env python3
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

MODULE_PATH = Path(__file__).resolve().parents[1] / "tools" / "zdosctl.py"
spec = importlib.util.spec_from_file_location("zdosctl", MODULE_PATH)
module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(module)


class ZdosCtlTests(unittest.TestCase):
    def test_target_contract_keeps_only_x86_verified(self):
        self.assertEqual(module.TARGETS["x86_64"]["status"], "VERIFIED")
        self.assertEqual(module.TARGETS["aarch64"]["status"], "PREPARED")
        self.assertEqual(module.TARGETS["riscv64"]["status"], "PREPARED")

    def test_readonly_policy_is_valid(self):
        policy = module.load_policy(Path(__file__).resolve().parents[1] / "policies" / "diagnostic-readonly.json")
        self.assertEqual(policy["name"], "zdos.diagnostic.readonly")
        self.assertEqual(policy["processes"]["exec"], [])
        self.assertEqual(policy["network"]["connect"], [])

    def test_unknown_policy_key_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.json"
            value = json.loads((Path(__file__).resolve().parents[1] / "policies" / "diagnostic-readonly.json").read_text())
            value["filesystem"]["shell_escape"] = True
            path.write_text(json.dumps(value))
            with self.assertRaises(ValueError):
                module.load_policy(path)

    def test_manifest_is_canonical_and_hashes_files(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "manifest.json"
            manifest = module.create_manifest(output)
            self.assertEqual(manifest["schema"], "zdos-artifact-manifest/v1")
            self.assertGreater(len(manifest["files"]), 0)
            self.assertTrue(all(len(entry["sha256"]) == 64 for entry in manifest["files"]))
            self.assertEqual(json.loads(output.read_text())["schema"], "zdos-artifact-manifest/v1")


if __name__ == "__main__":
    unittest.main()
