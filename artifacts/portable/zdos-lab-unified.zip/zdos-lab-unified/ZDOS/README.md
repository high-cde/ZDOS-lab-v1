![ZDOS — Unified Ecosystem](https://capsule-render.vercel.app/api?type=waving&color=0:09090b,35:312e81,68:2563eb,100:10b981&height=230&section=header&text=ZDOS&fontSize=78&fontColor=ffffff&animation=fadeIn&fontAlignY=38&desc=Unified%20Operating%20System%20%2B%20Zlang%20Ecosystem&descAlignY=61&descSize=20)

# ZDOS · ecosistema operativo, runtime e strumenti

[![Validate ZDOS x86_64](https://github.com/high-cde/ZDOS/actions/workflows/validate-x86_64.yml/badge.svg)](https://github.com/high-cde/ZDOS/actions/workflows/validate-x86_64.yml)
[![Linux distro](https://img.shields.io/badge/distro-ZDOS%20Linux%200.2-10b981?style=for-the-badge&logo=linux&logoColor=white)](distro/)
[![Bare metal](https://img.shields.io/badge/OS-bare--metal%20x86__64-2563eb?style=for-the-badge&logo=linux&logoColor=white)](os/x86_64/)
[![Runtime](https://img.shields.io/badge/runtime-ZLB2%20v2.5-7c3aed?style=for-the-badge&logo=rust&logoColor=white)](https://github.com/high-cde/Zlang)
[![ARM64 profile](https://img.shields.io/badge/profile-ARM64%20prepared-0e7490?style=for-the-badge&logo=arm&logoColor=white)](docs/HARDWARE_MATRIX.md)
[![RISC-V profile](https://img.shields.io/badge/profile-RISC--V%20prepared-f59e0b?style=for-the-badge)](docs/HARDWARE_MATRIX.md)
[![Portal](https://img.shields.io/badge/portal-ZDOS--SEC-ef4444?style=for-the-badge&logo=socketdotio&logoColor=white)](https://github.com/high-cde/ZDOS-SEC-PORTAL)
[![License](https://img.shields.io/badge/license-MIT-64748b?style=for-the-badge)](LICENSE)

> **ZDOS è un ecosistema in costruzione:** una distribuzione Linux minimale, un prototipo bare-metal x86_64, il runtime linguistico Zlang, strumenti di sviluppo, servizi di rete e un portale operativo. Ogni capacità viene dichiarata soltanto quando esistono codice, test e una prova osservabile.

## 🧭 Mappa dell’ecosistema

```mermaid
flowchart LR
    A[📝 Zlang source] --> B[⚙️ Zlang compiler]
    B --> C[🧩 ZLB2 v2.5 bytecode]
    C --> D[🧠 ZDOS bare metal]
    D --> E[💿 GRUB ISO]
    E --> F[🖥️ QEMU + CI]
    G[🐧 ZDOS Linux] --> H[📦 BusyBox + initramfs]
    H --> I[🌐 DHCP + persistence]
    J[🛰️ ZDOS-SEC-PORTAL] --> K[🔌 Socket.IO + APIs]
    D -. runtime .-> J
    G -. future services .-> J
```

## ✅ Cosa è verificato oggi

| Percorso | Stato | Prova |
|---|---|---|
| 🐧 **ZDOS Linux** | ISO live x86_64 con kernel Linux bootstrap, BusyBox, initramfs, account base, DHCP opzionale e persistenza `/dev/vda1` | `distro/build.sh` + boot QEMU con `ZDOS_READY` |
| 🧠 **ZDOS bare-metal** | Kernel freestanding x86_64, GRUB Multiboot2 e runtime Zlang incorporato | GitHub Actions + `os/x86_64/tools/verify_qemu.sh` |
| ⚙️ **Zlang** | Compilatore ZLB2 v2.5 e contratto bytecode verificato | [Repository Zlang](https://github.com/high-cde/Zlang) |
| 🛰️ **SEC Portal** | HUD web, feed sociale, ledger locale e stream Socket.IO | [Repository ZDOS-SEC-PORTAL](https://github.com/high-cde/ZDOS-SEC-PORTAL) |

## 🧰 Build unificata

Per costruire il target x86_64 e integrare Zlang, ZDOS-SEC, `core` e Ghostnet in una workspace con repository affiancati:

```sh
./scripts/zdos-unified-build.sh --target x86_64 --live
./scripts/zdos-unified-build.sh --target x86_64 --persistent
./scripts/zdos-unified-build.sh --target x86_64 --persistent --dry-run
```

Gli artefatti vengono scritti in `out/`: ISO base, layer unificato, manifest SHA-256 e, se `qemu-img` è disponibile, disco persistente QCOW2. Il builder non esegue `git push` e non sovrascrive i repository sorgente. La guida completa è in [`docs/UNIFIED_BUILD.md`](docs/UNIFIED_BUILD.md).

## 🧱 Profili hardware

| Target | Boot path | Stato | Requisiti mancanti |
|---|---|---|---|
| `x86_64` | BIOS/UEFI + GRUB | ✅ Verificato in QEMU | Test hardware fisico, installer e driver estesi |
| `aarch64` | UEFI/EBBR o U-Boot | 🧪 Preparato | Kernel ARM64, ACPI/device tree, console e driver |
| `riscv64` | OpenSBI/SBI + U-Boot o UEFI | 🧪 Preparato | Kernel RISC-V, SBI, allineamento boot e driver |
| `i686`, `armv7`, `mips64` | Firmware specifico | ⏳ Roadmap | Toolchain, ABI, bootloader e test dedicati |

Una badge di profilo non equivale a supporto operativo. Un target diventa verificato solo dopo build riproducibile, boot osservabile, test positivi e negativi e hardware dichiarato. Vedere [`docs/HARDWARE_MATRIX.md`](docs/HARDWARE_MATRIX.md).

## 🚀 Avvio rapido

### ZDOS Linux

```sh
git clone https://github.com/high-cde/ZDOS.git
cd ZDOS
./distro/build.sh
./distro/test-qemu.sh
```

La build produce `distro/build/zdos-linux-x86_64.iso`. Per avviare manualmente la console:

```sh
qemu-system-x86_64 \
  -cdrom distro/build/zdos-linux-x86_64.iso \
  -serial stdio -display none
```

La milestone Linux include l’utente `zdos`, il tentativo DHCP su `eth0` e il mount opzionale di `/dev/vda1` su `/mnt/data`. La procedura completa è descritta in [`distro/README.md`](distro/README.md).

### Prototipo ZDOS x86_64 + Zlang

Per la catena bare-metal, clonare Zlang accanto a ZDOS:

```sh
git clone https://github.com/high-cde/Zlang.git ../Zlang
cd os/x86_64
make clean
make verify
sh tools/verify_qemu.sh
```

L’output seriale atteso è:

```text
ZDOS x86_64 bootstrap
Zlang runtime ZLB2 v2.5 ready
ZDOS: native Zlang program executed
ZDOS: Zlang halted cleanly
```

## 📂 Struttura del repository

| Area | Responsabilità | Documentazione |
|---|---|---|
| `distro/` | Build della distro Linux, root filesystem, initramfs e test QEMU | [`distro/README.md`](distro/README.md) |
| `os/x86_64/` | Kernel bare-metal sperimentale e runtime ZLB2 v2.5 | [`os/x86_64/README.md`](os/x86_64/README.md) |
| `core/` | Cortex, AAAK, memoria e componenti di ricerca | [`docs/docs/overview.md`](docs/docs/overview.md) |
| `network/` | Nodi e servizi distribuiti | [`docs/docs/nodes.md`](docs/docs/nodes.md) |
| `interface/` | CLI, web dashboard e cloud interface | [`interface/web/README.md`](interface/web/README.md) |
| `os/ghostnet/` | Ricerca e componenti del sottosistema Ghostnet | [`os/ghostnet/README.md`](os/ghostnet/README.md) |
| `dev/zen/` | Toolchain e automazione per lo sviluppo | [`dev/zen/README.md`](dev/zen/README.md) |
| `docs/` | Architettura, operazioni, roadmap e contratti | [`docs/README.md`](docs/README.md) |

## 🆕 Novità implementate

La pipeline bare-metal ora usa un runtime **ZLB2 v2.5** coerente con l’header generato dal compilatore: magic e versione vengono validate, ogni record viene controllato nei propri limiti, gli opcode sconosciuti vengono rifiutati e `HALT` deve chiudere esattamente il buffer. Il bootstrap esegue realmente `EMIT`; gli altri record v2.5 vengono validati e restano esplicitamente in roadmap finché non saranno collegate capability sicure.

La build `os/x86_64/update_and_build.sh` è ora parametrica e non interattiva, mentre `scripts/setup_all.sh` controlla le dipendenze e indica gli entrypoint senza dichiarare servizi non avviati. La CI verifica separatamente il boot QEMU bare-metal, la build ISO e il contratto web PHP. La distro Linux continua a essere verificata con `ZDOS_READY` in QEMU.

Il portale web non simula più uno stato operativo: l’endpoint PHP restituisce `LOCAL_STATUS_ONLY` quando Tor non è raggiungibile, espone solo un probe TCP configurabile e dichiara esplicitamente che la risposta non certifica anonimato, cifratura o sicurezza. I controlli dei moduli nella UI sono presentati come laboratorio locale; l’esecuzione remota non viene dichiarata implementata.

L’estetica condivisa può essere applicata con un solo comando: `./scripts/apply-zdos-theme.sh`. Il tema fonde ciano e viola per Zlang, blu per il core ZDOS, verde per gli stati verificati e ambra per le capacità sperimentali. Il comando è idempotente: può essere rieseguito senza duplicare CSS o alterare la logica delle interfacce.

## 🔁 Orchestrazione dell’ecosistema

Per sincronizzare e verificare i tre repository in un’unica esecuzione, usare:

```sh
./scripts/sync-ecosystem.sh
```

L’orchestratore aggiorna soltanto branch fast-forward, rifiuta working tree locali non puliti, esegue test Zlang, gate ZLB2, build/boot bare-metal, build/boot della distro, Evidence Chain e controlli del portale SEC. Non usa reset distruttivi e si arresta al primo errore reale.

## ⛓️ ZDOS Evidence Chain

ZDOS include una prima Evidence Chain non monetaria: un ledger append-only JSONL con hash concatenati, ordine degli eventi, verifica dei limiti e attestazioni di build/boot. Non usa token, saldi o mining e non salva dati personali o segreti. La prova locale completa si avvia con un solo comando:

```sh
./scripts/bootstrap-evidence-chain.sh
```

Il contratto operativo è documentato in [`evidence/README.md`](evidence/README.md), la policy di release in [`evidence/policy.release.json`](evidence/policy.release.json) e il verificatore in [`evidence/ledger.py`](evidence/ledger.py). La versione corrente dimostra integrità e ordine locale; consenso BFT multi-nodo, PKI multi-organizzazione e storage delle prove fuori catena restano attività successive.

## 🧪 Gate di verifica

Prima di dichiarare una release verificata, eseguire almeno:

```sh
git diff --check
bash -n scripts/zdos-unified-build.sh
./scripts/zdos-unified-build.sh --target x86_64 --persistent --dry-run
./distro/test-qemu.sh
```

Il marker `ZDOS_READY` prova l'avvio dell'immagine e non certifica da solo rete, persistenza, sicurezza o compatibilità hardware generale.

## 🛡️ Confini e sicurezza

ZDOS non deve essere presentato come una distro general-purpose completa finché non dispone di package manager, installer, aggiornamenti firmati, gestione utenti completa, filesystem persistente verificato, rete configurabile e test hardware. La base attuale è una milestone reale e avviabile, ma alcune componenti restano sperimentali.

Il portale SEC contiene endpoint che avviano processi di build e, nel codice attuale, una password di sviluppo hard-coded. **Non esporre il portale su Internet senza autenticazione reale, secret tramite environment, rate limiting, validazione degli URL, sandbox del compilatore e audit degli eventi.** Vedere la documentazione del [portale SEC](https://github.com/high-cde/ZDOS-SEC-PORTAL) prima di un deployment.

## 📚 Documentazione essenziale

| Documento | Scopo |
|---|---|
| [`docs/UNIFIED_BUILD.md`](docs/UNIFIED_BUILD.md) | Builder unificato e profili di output |
| [`docs/HARDWARE_MATRIX.md`](docs/HARDWARE_MATRIX.md) | Architetture, firmware e livelli di supporto |
| [`docs/ECOSYSTEM.md`](docs/ECOSYSTEM.md) | Mappa dei repository e contratti tra i componenti |
| [`docs/OPERATIONS.md`](docs/OPERATIONS.md) | Build, boot, CI, troubleshooting e release |
| [`ARCHITECTURE.md`](ARCHITECTURE.md) | Architettura generale del monorepo |
| [`CONTRIBUTING.md`](CONTRIBUTING.md) | Workflow di contributo |
| [`SECURITY.md`](SECURITY.md) | Segnalazioni e principi di sicurezza |
| [Profilo ZLB2 v2.5](https://github.com/high-cde/Zlang/blob/main/docs/zdos-x86_64-profile.md) | Contratto tra compilatore Zlang e runtime ZDOS |
| [ZDOS-SEC-PORTAL](https://github.com/high-cde/ZDOS-SEC-PORTAL) | Portale HUD e API operative |

## 🤝 Contribuire

Prima di proporre una nuova capacità, descrivere il contratto, il limite, l’errore atteso, il test positivo e almeno un test negativo. Le modifiche devono mantenere il linguaggio visuale dell’ecosistema: sezioni leggibili, badge coerenti, diagrammi quando chiariscono l’architettura e limiti dichiarati senza ambiguità.

```sh
git checkout -b docs/nome-della-modifica
# modifica, verifica link e test locali
git diff --check
git commit -m "docs: descrivi la nuova capacità"
git push origin docs/nome-della-modifica
```

## 📜 Licenza

Questo progetto è distribuito secondo la licenza indicata in [`LICENSE`](LICENSE).

---

**ZDOS · Zlang · ZDOS-SEC** · _Build what you can prove._ ✨

![Footer](https://capsule-render.vercel.app/api?type=waving&color=0:10b981,42:2563eb,100:7c3aed&height=120&section=footer)


## 🧭 ZDOS Operational Cockpit

Il primo nucleo delle nuove capacità è `tools/zdosctl`: un comando standard-library che tratta sorgenti, target, policy e prove come un unico oggetto operativo. Non sostituisce ancora il kernel né dichiara sandbox runtime completa; fornisce però un gate locale riproducibile prima della build o dell’esecuzione.

```sh
# Introspezione di repository, commit, toolchain e target
./tools/zdosctl inspect
./tools/zdosctl inspect --json

# Manifest canonico con identità SHA-256 dei repository affiancati
./tools/zdosctl manifest --output out/zdos-artifact-manifest.json

# Policy capability: default-deny, nessuna rete o exec implicita
./tools/zdosctl policy check policies/diagnostic-readonly.json

# Integrità del ledger locale, quando esiste una catena inizializzata
./tools/zdosctl evidence verify
```

Il manifest identifica commit, profili hardware, policy e file sorgente; la policy separa metadati d’identità da capability operative come filesystem, rete, processi e risorse. Una policy sconosciuta o con chiavi non previste viene rifiutata prima dell’esecuzione. L’ISO x86_64 rimane **VERIFIED**; ARM64 e RISC-V rimangono **PREPARED**.

Il builder unificato integra automaticamente `zdosctl.py`, il wrapper `zdosctl`, le policy di riferimento e il runbook nel layer `/opt/zdos`. La capacità è quindi disponibile dentro l’immagine senza dipendenze Python esterne; la generazione del manifest dell’intero ecosistema avviene durante una build completa con ISO disponibile.

## 🧪 Test del nuovo nucleo

```sh
python3 -m unittest discover -s tests -p 'test_*.py' -v
python3 tools/zlangc.py /path/to/program.zlang --bytecode /tmp/program.zlb2 --header /tmp/program.h
```

I test verificano target e stati, policy valide e invalide, hash del manifest e magic/versione `ZLB2`. Il validatore non implica che una policy sia applicata dal kernel: fino al collegamento con syscall e runtime resta un **gate di preparazione verificabile**, non una sandbox completa.
