# API /rooms
