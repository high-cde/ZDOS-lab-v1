# ZDOS Unified Build

Il comando unico per generare la pipeline integrata è:

```sh
cd /home/ubuntu/zdos_analysis
./zdos-unified-build.sh --target x86_64 --persistent
```

Per una build live usare `./zdos-unified-build.sh --live`. Per controllare le operazioni senza eseguire la compilazione usare `./zdos-unified-build.sh --persistent --dry-run`. Lo script non esegue `git push`, non modifica i repository sorgente e scrive gli artefatti soltanto nella directory `out/`.

| Profilo | Risultato |
|---|---|
| `--live` | ISO ZDOS x86_64, layer unificato e manifest |
| `--persistent` | Gli stessi artefatti più un disco QCOW2, se `qemu-img` è installato |
| `--dry-run` | Verifica dei percorsi e stampa delle operazioni senza build |
| `--skip-build` | Usa un'ISO già presente in `ZDOS/distro/build/` |
| `--target x86_64` | Target verificato: build ISO Linux e QEMU |
| `--target aarch64` | Profilo ARM64 preparatorio; kernel e driver da implementare |
| `--target riscv64` | Profilo RISC-V preparatorio; kernel, SBI e driver da implementare |

La pipeline integra ZDOS Linux, il compilatore/runtime Zlang, il portale ZDOS-SEC e i moduli `core`/Ghostnet come layer riproducibile. Il parametro `--target` rende esplicito il profilo hardware invece di confondere una singola ISO con un supporto universale. L'ISO base corrente è però una distribuzione Linux x86_64 con GRUB, kernel Linux, BusyBox e initramfs; il requisito **“compilata solo in Zlang”** non è ancora raggiunto dall'ecosistema esistente. Anche il supporto a “tutti i tipi di hardware” non può essere garantito da un singolo binario: richiede kernel, driver, firmware e profili per architettura.

Per arrivare a ZDOS nativo in Zlang servono, in ordine, un backend nativo stabile per Zlang, un ABI documentato, un bootstrap minimo assembly, gestione memoria, scheduler, interrupt, driver, filesystem, rete, boot BIOS/UEFI, test QEMU e test su hardware dichiarato. Il comando attuale realizza invece il massimo percorso verificabile senza inventare capacità non implementate.
