# ZDOS Hardware Matrix

## Stato dei target

| Target | Architettura | Firmware/boot | Stato attuale | Prossimo requisito |
|---|---|---|---|---|
| `x86_64` | PC/server 64-bit | BIOS/UEFI + GRUB | **Verificato** per ISO Linux e QEMU | Driver hardware, installer e test su macchine fisiche |
| `aarch64` | ARM 64-bit | UEFI/EBBR oppure U-Boot | **Profilo preparatorio** | Kernel ARM64, device tree/ACPI, console, driver e QEMU `virt` |
| `riscv64` | RISC-V 64-bit | OpenSBI/SBI + U-Boot o UEFI | **Profilo preparatorio** | Kernel RISC-V, allineamento boot, SBI, console, driver e QEMU `virt` |
| `i686` | PC 32-bit legacy | BIOS + GRUB | **Non implementato** | Toolchain, linker script, kernel e test dedicati |
| `armv7` | ARM 32-bit | U-Boot/board-specific | **Non implementato** | Kernel 32-bit, device tree e profili per scheda |
| `mips64` | MIPS 64-bit | Board-specific | **Non implementato** | Bootloader, ABI e toolchain dedicati |

## Regola di supporto

Un target può essere dichiarato **verificato** soltanto quando esistono una toolchain fissata, un artefatto riproducibile, un percorso di boot osservabile, test positivi e negativi e almeno un ambiente target dichiarato. La presenza di un nome nell'interfaccia non equivale a supporto hardware.

## Architettura di integrazione

Il livello hardware deve restare separato dal linguaggio. Il bootstrap iniziale usa il firmware e il bootloader del target; il kernel espone poi un ABI stabile al runtime Zlang. In questo modo Zlang può essere portabile senza obbligare il compilatore a conoscere ogni dispositivo.

```text
firmware -> bootloader -> kernel/ABI -> driver -> ZDOS services -> Zlang runtime -> applications/SEC
```

Per ARM64 il percorso previsto è UEFI/EBBR o U-Boot con device tree/ACPI. Per RISC-V il percorso deve rispettare SBI/OpenSBI e i requisiti di allineamento del kernel. I profili sono stati aggiunti al builder, ma soltanto x86_64 invoca oggi la build effettiva dell'ISO.

## Riferimenti

[1]: https://uefi.org/specs/UEFI/2.11/02_Overview.html "UEFI Specification 2.11"
[2]: https://arm-software.github.io/ebbr/ "Embedded Base Boot Requirements"
[3]: https://docs.kernel.org/arch/riscv/boot.html "Linux RISC-V Kernel Boot Requirements"
[4]: https://github.com/riscv-non-isa/riscv-sbi-doc "RISC-V SBI specification"
