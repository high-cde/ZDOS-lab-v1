#!/usr/bin/env python3
"""ZDOS operational cockpit.

This tool deliberately uses only the Python standard library. It exposes the
same evidence-first contract to developers, CI and the boot/build workspace:
inspect the ecosystem, create a canonical manifest, verify the local ledger,
and reject unsafe capability policies before execution.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

STATUSES = {"VERIFIED", "PREPARED", "EXPERIMENTAL", "NOT_VERIFIED"}
TARGETS = {
    "x86_64": {"status": "VERIFIED", "boot": "BIOS/UEFI + GRUB", "note": "Linux ISO and QEMU path"},
    "aarch64": {"status": "PREPARED", "boot": "UEFI/EBBR or U-Boot", "note": "kernel and device-tree work pending"},
    "riscv64": {"status": "PREPARED", "boot": "OpenSBI/SBI", "note": "kernel and SBI path work pending"},
}
POLICY_KEYS = {"name", "version", "filesystem", "network", "processes", "registry", "resources", "identity"}
CAPABILITY_KEYS = {"read", "write", "connect", "exec", "keys", "max_memory_mb", "max_fds", "timeout_ms"}


def repo_root() -> Path:
    return Path(os.environ.get("ZDOS_ROOT", Path(__file__).resolve().parents[1])).resolve()


def workspace() -> dict[str, Path]:
    root = repo_root()
    base = Path(os.environ.get("ZDOS_WORKSPACE", root.parent)).resolve()
    return {
        "ZDOS": root,
        "Zlang": Path(os.environ.get("ZLANG_ROOT", base / "Zlang")).resolve(),
        "SEC": Path(os.environ.get("SEC_ROOT", base / "ZDOS-SEC-PORTAL")).resolve(),
    }


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def git_commit(path: Path) -> str:
    try:
        return subprocess.check_output(["git", "-C", str(path), "rev-parse", "HEAD"], text=True, stderr=subprocess.DEVNULL).strip()
    except (OSError, subprocess.CalledProcessError):
        return "unknown"


def json_dump(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2))


def inspect_ecosystem() -> dict[str, Any]:
    paths = workspace()
    commands = {name: bool(shutil.which(name)) for name in ("bash", "sha256sum", "find", "tar", "git", "python3")}
    repositories = {}
    for name, path in paths.items():
        repositories[name] = {
            "path": str(path),
            "present": path.is_dir(),
            "commit": git_commit(path) if path.is_dir() else "unknown",
        }
    return {
        "schema": "zdos-inspection/v1",
        "zdos_root": str(paths["ZDOS"]),
        "repositories": repositories,
        "commands": commands,
        "targets": TARGETS,
        "policy": "default-deny",
        "evidence_ledger": str(paths["ZDOS"] / "evidence" / "ledger.jsonl"),
    }


def iter_source_files() -> list[tuple[str, Path]]:
    files: list[tuple[str, Path]] = []
    for label, root in workspace().items():
        if not root.is_dir():
            continue
        for path in sorted(root.rglob("*")):
            if not path.is_file():
                continue
            relative = path.relative_to(root)
            if any(part in {".git", "__pycache__", "target", "node_modules", "out", "dist"} for part in relative.parts):
                continue
            files.append((f"{label}/{relative.as_posix()}", path))
    return files


def create_manifest(output: Path) -> dict[str, Any]:
    paths = workspace()
    entries = [{"path": name, "sha256": sha256_file(path), "size": path.stat().st_size} for name, path in iter_source_files()]
    manifest = {
        "schema": "zdos-artifact-manifest/v1",
        "repositories": {name: {"path": str(path), "commit": git_commit(path)} for name, path in paths.items()},
        "target_profiles": TARGETS,
        "policy": "default-deny",
        "files": entries,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    return manifest


def load_policy(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("policy must be a JSON object")
    unknown = set(value) - POLICY_KEYS
    if unknown:
        raise ValueError(f"unknown policy keys: {', '.join(sorted(unknown))}")
    required = {"name", "version", "filesystem", "network", "processes", "resources", "identity"}
    missing = required - set(value)
    if missing:
        raise ValueError(f"missing policy keys: {', '.join(sorted(missing))}")
    if not isinstance(value["name"], str) or not value["name"]:
        raise ValueError("policy.name must be a non-empty string")
    if not isinstance(value["version"], int) or value["version"] < 1:
        raise ValueError("policy.version must be a positive integer")
    for section in ("filesystem", "network", "processes", "registry", "resources"):
        if not isinstance(value[section], dict):
            raise ValueError(f"policy.{section} must be an object")
        unknown_caps = set(value[section]) - CAPABILITY_KEYS
        if unknown_caps:
            raise ValueError(f"unknown {section} capability keys: {', '.join(sorted(unknown_caps))}")
    if not isinstance(value["identity"], dict):
        raise ValueError("policy.identity must be an object")
    if "owner" not in value["identity"] or "signer" not in value["identity"]:
        raise ValueError("policy.identity requires owner and signer")
    resources = value["resources"]
    for key in ("max_memory_mb", "max_fds", "timeout_ms"):
        if key in resources and (not isinstance(resources[key], int) or resources[key] < 0):
            raise ValueError(f"policy.resources.{key} must be a non-negative integer")
    return value


def verify_evidence() -> tuple[bool, str]:
    ledger_path = workspace()["ZDOS"] / "evidence" / "ledger.py"
    ledger_file = workspace()["ZDOS"] / "evidence" / "ledger.jsonl"
    if not ledger_path.is_file():
        return False, f"ledger implementation missing: {ledger_path}"
    if not ledger_file.is_file():
        return False, f"ledger is empty or missing: {ledger_file}"
    import importlib.util
    spec = importlib.util.spec_from_file_location("zdos_evidence_ledger", ledger_path)
    if spec is None or spec.loader is None:
        return False, "unable to load evidence ledger"
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.verify(ledger_file, os.getenv("ZDOS_EVIDENCE_KEY"))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="ZDOS evidence-first operational cockpit")
    parser.add_argument("--json", action="store_true", help="emit machine-readable JSON when supported")
    sub = parser.add_subparsers(dest="command", required=True)
    inspect = sub.add_parser("inspect", help="inspect repositories, toolchain and targets")
    inspect.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    manifest = sub.add_parser("manifest", help="create a canonical SHA-256 source manifest")
    manifest.add_argument("--output", default="out/zdos-artifact-manifest.json")
    evidence = sub.add_parser("evidence", help="verify the append-only Evidence Chain")
    evidence.add_argument("action", choices=("verify",))
    policy = sub.add_parser("policy", help="validate a capability policy before execution")
    policy.add_argument("action", choices=("check",))
    policy.add_argument("path")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "inspect":
            result = inspect_ecosystem()
            if args.json:
                json_dump(result)
            else:
                print("ZDOS operational inspection")
                print(f"root: {result['zdos_root']}")
                print(f"policy: {result['policy']}")
                for name, repo in result["repositories"].items():
                    state = "present" if repo["present"] else "missing"
                    print(f"{name}: {state} commit={repo['commit']}")
                for target, profile in result["targets"].items():
                    print(f"target {target}: {profile['status']} ({profile['note']})")
            return 0
        if args.command == "manifest":
            result = create_manifest(Path(args.output).resolve())
            print(json.dumps({"manifest": str(Path(args.output).resolve()), "files": len(result["files"]), "schema": result["schema"]}, indent=2))
            return 0
        if args.command == "evidence":
            ok, reason = verify_evidence()
            print(reason)
            return 0 if ok else 1
        if args.command == "policy":
            policy = load_policy(Path(args.path).resolve())
            print(json.dumps({"valid": True, "name": policy["name"], "version": policy["version"], "mode": "default-deny"}, indent=2))
            return 0
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"zdosctl error: {exc}", file=sys.stderr)
        return 1
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
